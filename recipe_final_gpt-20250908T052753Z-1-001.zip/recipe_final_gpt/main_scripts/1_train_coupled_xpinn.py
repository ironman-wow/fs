# main_scripts/1_train_coupled_xpinn.py
from _bootstrap import *  # noqa

import os
import torch
from src.core.config_loader import load_config, fix_seeds, get_device
from src.core.trainer import XPINNTrainer
from src.core.data_sampler import DataSampler
from src.architectures.coupled_xpinn import CoupledXPINN, make_networks
from src.utils.plotting import plot_training_curves

CFG_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "config", "process_recipe.json")
)

def main():
    cfg = load_config(CFG_PATH)
    print(f"[debug] Using config at: {CFG_PATH}")
    print(f"[debug] epochs={cfg['training']['epochs']}, lr={cfg['training']['lr']}")
    device = get_device(cfg)
    fix_seeds(cfg.get("seed", 42))

    os.makedirs(cfg["output"]["checkpoint_dir"], exist_ok=True)
    os.makedirs(cfg["output"]["fig_dir"], exist_ok=True)

    sampler = DataSampler(cfg, device)
    nets = make_networks(cfg).to(device)
    model = CoupledXPINN(cfg, nets).to(device)

    trainer = XPINNTrainer(cfg, model, sampler, device)
    hist = trainer.train()

    torch.save(
        model.state_dict(),
        os.path.join(cfg["output"]["checkpoint_dir"], "xpinn.pt")
    )
    plot_training_curves(hist["losses"], cfg["output"]["loss_plot_path"])

if __name__ == "__main__":
    main()
