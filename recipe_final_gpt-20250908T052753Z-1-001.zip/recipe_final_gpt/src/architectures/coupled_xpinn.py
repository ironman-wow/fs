# src/architectures/coupled_xpinn.py
from typing import Dict
import torch
import torch.nn as nn

from src.networks.base_network import MLP
from src.networks.thermal_net import ThermalHead
from src.networks.cvd_net import CVDHead
from src.networks.plasma_etch_net import PlasmaHead
from src.networks.stress_net import StressHead

from src.physics_losses.thermal_loss import thermal_residuals
from src.physics_losses.cvd_loss import cvd_residuals
from src.physics_losses.plasma_etch_loss import plasma_residuals
from src.physics_losses.stress_loss import stress_residuals

__all__ = ["SharedEncoder", "CoupledXPINN", "make_networks"]

class SharedEncoder(MLP):
    """Shared feature encoder for X = [x,y,t,T_chuck,P_chamber,P_rf,SiH4,NH3,AUX1,AUX2]."""
    def __init__(self, in_dim: int, out_dim: int, width: int = 128, depth: int = 4):
        super().__init__(in_dim, out_dim, width=width, depth=depth)

class CoupledXPINN(nn.Module):
    """
    Forward:
      forward_fields(X) -> dict of predicted fields
    Training:
      physics_losses(batch) -> dict of scalar losses
    """
    def __init__(self, cfg: dict, nets: nn.Module):
        super().__init__()
        self.cfg = cfg
        nc = cfg["network_configs"]
        self.encoder = SharedEncoder(
            nc["shared_encoder"]["in_dim"],
            nc["shared_encoder"]["out_dim"],
            width=nc["shared_encoder"]["width"],
            depth=nc["shared_encoder"]["depth"],
        )
        # Specialist heads
        self.thermal = getattr(nets, "thermal")
        self.cvd     = getattr(nets, "cvd")
        self.plasma  = getattr(nets, "plasma")
        self.stress  = getattr(nets, "stress")

        self.active     = set(cfg["active_physics"])
        self.constants  = cfg["physics_constants"]

    def forward_fields(self, X: torch.Tensor) -> Dict[str, torch.Tensor]:
        shared = self.encoder(X)
        out: Dict[str, torch.Tensor] = {}

        # Order: thermal → plasma → cvd → stress
        if "thermal" in self.active:
            out |= self.thermal(shared, X)

        if "plasma" in self.active:
            out |= self.plasma(shared, X, self.constants)

        if "cvd" in self.active:
            if "T" not in out:
                raise RuntimeError("CVD requires 'T' from Thermal; enable 'thermal'.")
            out |= self.cvd(shared, X, deps=out, constants=self.constants)

        if "stress" in self.active:
            if "T" not in out:
                raise RuntimeError("Stress requires 'T' from Thermal; enable 'thermal'.")
            out |= self.stress(shared, X, deps=out, constants=self.constants)

        return out

    def physics_losses(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        pde, ic, bc = batch["pde"], batch["ic"], batch["bc"]

        out_pde = self.forward_fields(pde)
        out_ic  = self.forward_fields(ic)
        out_bc  = self.forward_fields(bc)

        losses: Dict[str, torch.Tensor] = {}
        if "thermal" in self.active:
            losses["thermal"] = thermal_residuals(pde, ic, bc, out_pde, out_ic, out_bc, self.constants)
        if "plasma" in self.active:
            losses["plasma"]  = plasma_residuals(pde, out_pde, self.constants)
        if "cvd" in self.active:
            losses["cvd"]     = cvd_residuals(pde, ic, out_pde, out_ic, self.constants)
        if "stress" in self.active:
            losses["stress"]  = stress_residuals(pde, out_pde, self.constants)

        # keep an interfaces key (benign) to match config lambdas
        losses["interfaces"] = torch.zeros(1, device=pde.device, dtype=pde.dtype)
        return losses

def make_networks(cfg: dict) -> nn.Module:
    """
    Build specialist heads and return a container module with attributes:
      .thermal, .cvd, .plasma, .stress
    """
    nc = cfg["network_configs"]
    thermal = ThermalHead(nc["thermal"]["in_dim"], nc["thermal"]["out_dim"])
    cvd     = CVDHead(nc["cvd"]["in_dim"], nc["cvd"]["out_dim"])
    plasma  = PlasmaHead(nc["plasma"]["in_dim"], nc["plasma"]["out_dim"])
    stress  = StressHead(nc["stress"]["in_dim"], nc["stress"]["out_dim"])

    class Nets(nn.Module):
        def __init__(self):
            super().__init__()
            self.thermal = thermal
            self.cvd     = cvd
            self.plasma  = plasma
            self.stress  = stress
        def __getitem__(self, k):  # optional
            return getattr(self, k)

    return Nets()
