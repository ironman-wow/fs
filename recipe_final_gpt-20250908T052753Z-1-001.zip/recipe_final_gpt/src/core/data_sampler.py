# src/core/data_sampler.py
from typing import Dict
import torch
from torch.quasirandom import SobolEngine


class DataSampler:
    """
    Sobol/uniform sampling over (x, y, t) within a wafer disk; attaches recipe params.
    Returns dicts with collocation points for PDE, BC, IC and a dense grid for
    visualization / field evaluation.

    Input feature order everywhere:
      [x, y, t, T_chuck, P_chamber, P_rf, SiH4, NH3, AUX1, AUX2]  -> (N, 10)
    """

    def __init__(self, cfg: dict, device: torch.device):
        self.cfg = cfg
        self.device = device

        dom = cfg["domain"]
        self.xmin, self.xmax = dom["x_range"]
        self.ymin, self.ymax = dom["y_range"]
        self.tmin, self.tmax = dom["t_range"]
        self.R = dom["wafer_radius"]

        self.n_points = cfg["training"]["batch_points"]
        self.sobol = SobolEngine(dimension=3, scramble=True)

    def _sample_xy_in_disc(self, n: int) -> torch.Tensor:
        """
        Rejection sampling in the bounding box, accept points inside x^2 + y^2 <= R^2.
        Returns (n, 2) tensor on device.
        """
        samples = []
        count = 0
        # Oversample up to 10x attempts to fill; concatenate accepted points.
        while len(samples) < n and count < 10 * n:
            xy = torch.rand((n, 2), device=self.device)
            xy[:, 0] = self.xmin + (self.xmax - self.xmin) * xy[:, 0]
            xy[:, 1] = self.ymin + (self.ymax - self.ymin) * xy[:, 1]
            mask = (xy[:, 0] ** 2 + xy[:, 1] ** 2) <= (self.R ** 2)
            if mask.any():
                samples.append(xy[mask])
            count += 1
        if not samples:
            # Fallback (shouldn't happen with reasonable R)
            return torch.zeros((n, 2), device=self.device)
        return torch.cat(samples, dim=0)[:n]

    def _sample_t(self, n: int) -> torch.Tensor:
        u = torch.rand((n, 1), device=self.device)
        return self.tmin + (self.tmax - self.tmin) * u

    def _sample_recipe(self, n: int) -> Dict[str, torch.Tensor]:
        rr = self.cfg["recipe_parameter_ranges"]
        T = rr["T_chuck"]
        P = rr["P_chamber"]
        Prf = rr["P_rf"]
        SiH4 = rr["flows_sccm"]["SiH4"]
        NH3 = rr["flows_sccm"]["NH3"]

        def uni(a, b):
            return a + (b - a) * torch.rand((n, 1), device=self.device)

        return {
            "T_chuck": uni(T[0], T[1]),
            "P_chamber": uni(P[0], P[1]),
            "P_rf": uni(Prf[0], Prf[1]),
            "SiH4": uni(SiH4[0], SiH4[1]),
            "NH3": uni(NH3[0], NH3[1]),
        }

    def _pack(self, xy: torch.Tensor, t: torch.Tensor, recipe: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Build the input feature tensor in the canonical order.
        """
        n = xy.shape[0]
        aux = torch.zeros((n, 2), device=self.device)
        xyt = torch.cat([xy, t], dim=1)
        recipe_vec = torch.cat(
            [
                recipe["T_chuck"],
                recipe["P_chamber"],
                recipe["P_rf"],
                recipe["SiH4"],
                recipe["NH3"],
            ],
            dim=1,
        )
        return torch.cat([xyt, recipe_vec, aux], dim=1)

    def sample_batch(self) -> Dict[str, torch.Tensor]:
        """
        Returns:
          {
            "pde":  (N_pde, 10)  with requires_grad=True
            "ic":   (N_ic,  10)  with requires_grad=True (t = tmin)
            "bc":   (N_bc,  10)  with requires_grad=True (r = R edge points)
            "grid": (H*W,  10)   mid-time grid for visualization/eval
            "meta": dict        mean recipe params of the PDE batch
          }
        """
        n_pde = self.n_points["pde"]
        n_bc = self.n_points["bc"]
        n_ic = self.n_points["ic"]

        # PDE interior
        xy = self._sample_xy_in_disc(n_pde)
        t = self._sample_t(n_pde)
        rec = self._sample_recipe(n_pde)
        pde = self._pack(xy, t, rec).requires_grad_(True)

        # IC at t = tmin
        xy_ic = self._sample_xy_in_disc(n_ic)
        t_ic = torch.full((n_ic, 1), self.tmin, device=self.device)
        rec_ic = self._sample_recipe(n_ic)
        ic = self._pack(xy_ic, t_ic, rec_ic).requires_grad_(True)

        # BC on wafer edge (r = R): use Neumann-like (insulated) for T via radial gradient
        theta = 2 * torch.pi * torch.rand((n_bc, 1), device=self.device)
        x_bc = self.R * torch.cos(theta)
        y_bc = self.R * torch.sin(theta)
        xy_bc = torch.cat([x_bc, y_bc], dim=1)
        t_bc = self._sample_t(n_bc)
        rec_bc = self._sample_recipe(n_bc)
        bc = self._pack(xy_bc, t_bc, rec_bc).requires_grad_(True)

        # Dense grid for visualization (mid-time)
        H = W = 64
        xs = torch.linspace(self.xmin, self.xmax, W, device=self.device)
        ys = torch.linspace(self.ymin, self.ymax, H, device=self.device)
        X, Y = torch.meshgrid(xs, ys, indexing="xy")
        Tmid = torch.full_like(X.reshape(-1, 1), (self.tmin + self.tmax) / 2)
        rec_g = self._sample_recipe(X.numel())
        grid = self._pack(torch.stack([X.reshape(-1), Y.reshape(-1)], dim=1), Tmid, rec_g)

        meta = {k: v.mean().item() for k, v in rec.items()}

        return {"pde": pde, "ic": ic, "bc": bc, "grid": grid, "meta": meta}
