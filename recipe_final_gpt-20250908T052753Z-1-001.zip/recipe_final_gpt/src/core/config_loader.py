import json
import os
import random
import numpy as np
import torch


def load_config(path: str) -> dict:
    path = os.path.abspath(path)
    with open(path, 'r') as f:
        cfg = json.load(f)
    return cfg


def fix_seeds(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_device(cfg: dict):
    if cfg.get('device', 'auto') == 'auto':
        return torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    return torch.device(cfg['device'])
