# src/core/trainer.py
from typing import Dict
import torch
from torch import nn
from tqdm import trange

class XPINNTrainer:
    def __init__(self, cfg: dict, model: nn.Module, sampler, device):
        self.cfg = cfg
        self.model = model
        self.sampler = sampler
        self.device = device

        self.lr = cfg["training"]["lr"]
        self.epochs = cfg["training"]["epochs"]
        self.grad_clip = cfg["training"].get("grad_clip", 0.0)
        self.loss_weights = cfg["training"]["lambda"]

        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)

        # AMP setup (new API). Enable only on CUDA.
        self.device_type = "cuda" if device.type == "cuda" else "cpu"
        self.use_amp = (self.device_type == "cuda")
        self.scaler = torch.amp.GradScaler(self.device_type) if self.use_amp else None

        self.history = {"losses": []}

    def train(self) -> Dict[str, list]:
        self.model.train()
        loop = trange(self.epochs)

        for _ in loop:
            batch = self.sampler.sample_batch()

            # forward + losses under autocast (CUDA only)
            if self.use_amp:
                with torch.amp.autocast(self.device_type, dtype=torch.float16):
                    losses = self.model.physics_losses(batch)
                    total = torch.tensor(0.0, device=self.device)
                    for k, v in losses.items():
                        total = total + self.loss_weights.get(k, 1.0) * v
            else:
                losses = self.model.physics_losses(batch)
                total = torch.tensor(0.0, device=self.device)
                for k, v in losses.items():
                    total = total + self.loss_weights.get(k, 1.0) * v

            if not torch.isfinite(total):
                # skip bad step
                self.optimizer.zero_grad(set_to_none=True)
                loop.set_description("L=nonfinite (skipped)")
                continue

            self.optimizer.zero_grad(set_to_none=True)

            if self.use_amp:
                self.scaler.scale(total).backward()
                if self.grad_clip and self.grad_clip > 0:
                    # unscale before clipping
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                total.backward()
                if self.grad_clip and self.grad_clip > 0:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
                self.optimizer.step()

            log = {k: v.item() for k, v in losses.items()}
            log["total"] = total.item()
            self.history["losses"].append(log)
            loop.set_description(f"L={total.item():.4e}")

        return self.history
