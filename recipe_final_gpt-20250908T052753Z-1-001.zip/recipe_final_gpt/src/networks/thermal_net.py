# src/networks/thermal_net.py
import torch
import torch.nn as nn
from .base_network import MLP


class ThermalHead(nn.Module):
    """Predict wafer temperature T(x, y, t)."""
    def __init__(self, in_dim: int, out_dim: int):
        super().__init__()
        self.mlp = MLP(in_dim, out_dim, width=128, depth=3)

    def forward(self, shared: torch.Tensor, X: torch.Tensor) -> dict:
        T = self.mlp(shared)
        return {"T": T}
