# src/networks/stress_net.py
import torch
import torch.nn as nn
from .base_network import MLP


class StressHead(nn.Module):
    """
    Predict biaxial stress sigma (Pa).
    The physics loss (plane-stress law) ties sigma to temperature elsewhere.
    """
    def __init__(self, in_dim: int, out_dim: int):
        super().__init__()
        self.mlp = MLP(in_dim, out_dim, width=128, depth=2)

    def forward(self, shared: torch.Tensor,
                X: torch.Tensor,
                deps: dict,
                constants: dict) -> dict:
        """
        Args:
            shared: (N, F) shared encoder features
            X:      (N, 10) raw input features [x,y,t,T_chuck,P,P_rf,SiH4,NH3,AUX1,AUX2]
            deps:   dict of dependent fields (e.g., may include 'T')
            constants: physics constants (unused here; used in loss)
        Returns:
            {'sigma': (N, 1)} predicted stress
        """
        sigma = self.mlp(shared)
        return {"sigma": sigma}
