# src/networks/plasma_etch_net.py
import torch
import torch.nn as nn
from .base_network import MLP


class PlasmaHead(nn.Module):
    """
    Predict plasma quantities: (phi, n_e, n_i).
    Outputs:
      - phi: electrostatic potential [V]
      - n_e: electron density [1/m^3]
      - n_i: ion density [1/m^3]
    """
    def __init__(self, in_dim: int, out_dim: int):
        super().__init__()
        assert out_dim == 3, "PlasmaHead must output [phi, n_e, n_i] -> out_dim=3"
        self.mlp = MLP(in_dim, out_dim, width=128, depth=3)

    def forward(self, shared: torch.Tensor, X: torch.Tensor, constants: dict):
        """
        Args:
            shared: (N, F) features from shared encoder
            X: (N, D) original input (unused here but kept for interface parity)
            constants: dict of plasma constants (unused in head; used in losses)
        Returns:
            dict with keys: 'phi', 'n_e', 'n_i'
        """
        y = self.mlp(shared)
        phi = y[:, 0:1]
        n_e = torch.relu(y[:, 1:2]) + 1e10  # enforce positivity with small floor
        n_i = torch.relu(y[:, 2:3]) + 1e10
        return {"phi": phi, "n_e": n_e, "n_i": n_i}
