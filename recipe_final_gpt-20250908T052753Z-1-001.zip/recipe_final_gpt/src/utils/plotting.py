# src/utils/plotting.py
import os
import matplotlib.pyplot as plt

def plot_training_curves(history, save_path):
    """
    Plot total loss and individual component losses over epochs.

    Args:
        history (list[dict]): Each item is a dict of loss_name -> float. Must include "total".
        save_path (str): Where to save the PNG.
    """
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    plt.figure()
    if not history:
        plt.title("Training Losses (no data)")
        plt.savefig(save_path, dpi=140)
        plt.close()
        return

    xs = list(range(len(history)))

    # Total loss
    plt.plot(xs, [h["total"] for h in history], label="total")

    # Component losses
    for k in history[0].keys():
        if k == "total":
            continue
        plt.plot(xs, [h[k] for h in history], label=k, alpha=0.6)

    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=140)
    plt.close()
