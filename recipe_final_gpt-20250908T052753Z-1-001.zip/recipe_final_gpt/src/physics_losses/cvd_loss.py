# src/physics_losses/cvd_loss.py
import torch

# ---- Stabilized Arrhenius + normalized concentration ---------------------------------
# - Ensure the temperature used in exponent is strictly positive & reasonable
#   via a smooth clamp (softplus around a floor).
# - Normalize flows/pressure to O(1) so reaction rates are well scaled.
# - Clamp the exponent range to avoid exp() overflow.
# --------------------------------------------------------------------------------------

def _softplus_floor(x, floor=250.0):
    # Smoothly enforce x >= floor
    return floor + torch.nn.functional.softplus(x - floor)

def _safe_arrhenius(k0, Ea, kB, T, max_abs_exponent=60.0):
    # exponent = -Ea / (kB * T_eff)
    T_eff = _softplus_floor(T, floor=250.0)  # Kelvin
    expo = -Ea / (kB * T_eff)
    expo = torch.clamp(expo, min=-max_abs_exponent, max=max_abs_exponent)
    return k0 * torch.exp(expo)

def cvd_residuals(pde_pts, ic_pts, out_pde, out_ic, constants):
    """
    Enforces stabilized Langmuir surface coverage ODE with Arrhenius temperature dependence:
        dθ/dt = k_ads * C * (1-θ) - k_des * θ - k_react * θ
    and regularizes θ ∈ [0,1], R_dep >= 0. Uses normalized "concentration" proxy C.
    """
    kB = constants['cvd']['k_B']

    # Use the network temperature but make it safe for Arrhenius
    T_pred = out_pde['T']
    T_safe = _softplus_floor(T_pred, floor=250.0)

    theta = out_pde['theta']           # (N,1), 0..1 after sigmoid in head (but still regularize)
    R_dep = out_pde['R_dep']           # (N,1), >=0 after softplus

    # Time derivative dθ/dt
    g_theta = torch.autograd.grad(theta, pde_pts,
                                  grad_outputs=torch.ones_like(theta),
                                  create_graph=True)[0]
    dtheta_dt = g_theta[:, 2:3]  # t is column 2

    # ---- Normalized "concentration" proxy C (dimensionless, ~ O(1)) ------------------
    # Inputs layout: [x,y,t,T_chuck,P_chamber,P_rf,SiH4,NH3,AUX1,AUX2]
    P_norm   = pde_pts[:, 4:5] / 400.0    # chamber pressure normalized to max range
    SiH4_n   = pde_pts[:, 6:7] / 200.0
    NH3_n    = pde_pts[:, 7:8] / 400.0
    C = (SiH4_n + NH3_n) * P_norm         # in [0, ~2]

    # ---- Stable Arrhenius rates -------------------------------------------------------
    k_ads   = _safe_arrhenius(constants['cvd']['k0_ads'],   constants['cvd']['Ea_ads'],   kB, T_safe)
    k_des   = _safe_arrhenius(constants['cvd']['k0_des'],   constants['cvd']['Ea_des'],   kB, T_safe)
    k_react = _safe_arrhenius(constants['cvd']['k0_react'], constants['cvd']['Ea_react'], kB, T_safe)

    # θ ODE residual
    ode_theta = dtheta_dt - (k_ads * C * (1.0 - theta) - k_des * theta - k_react * theta)

    # IC: θ(tmin) = 0
    theta_ic = out_ic['theta']
    res_ic = theta_ic - 0.0

    # Regularization: keep θ within [0,1] and R_dep non-negative (heads already enforce, this is for safety)
    reg = torch.mean(torch.relu(-R_dep)) + torch.mean(torch.relu(theta - 1.0)) + torch.mean(torch.relu(-theta))

    # Final loss (balanced; small weight on reg)
    return torch.mean(ode_theta**2) + 0.1 * torch.mean(res_ic**2) + 0.01 * reg
