# src/physics_losses/stress_loss.py
import torch

# Biaxial plane-stress for thin films on rigid substrate:
#   sigma = E * alpha_th * (T - T_ref) / (1 - nu)
# Here we anchor T_ref to the chuck temperature in inputs (column 3).

def stress_residuals(pde_pts, out_pde, constants):
    E = constants["stress"]["E"]
    nu = constants["stress"]["nu"]
    alpha = constants["stress"]["alpha_th"]

    T = out_pde["T"]
    sigma_pred = out_pde["sigma"]

    T_ref = pde_pts[:, 3:4]  # T_chuck as reference
    sigma_phys = E * alpha * (T - T_ref) / (1.0 - nu)

    return torch.mean((sigma_pred - sigma_phys) ** 2)
