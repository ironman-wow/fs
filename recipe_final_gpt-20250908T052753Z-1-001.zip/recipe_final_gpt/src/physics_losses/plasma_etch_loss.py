# src/physics_losses/plasma_etch_loss.py
import torch

# Drift–diffusion (steady):
#   ∇·J_e = 0,  J_e = -q μ_e n_e ∇φ + q D_e ∇n_e
#   ∇·J_i = 0,  J_i = +q μ_i n_i ∇φ - q D_i ∇n_i
# Poisson:
#   -∇·(ε ∇φ) = q (n_i - n_e)

def plasma_residuals(pde_pts, out_pde, constants):
    eps = constants["plasma"]["epsilon"]
    q   = constants["plasma"]["q"]
    mu_e, mu_i = constants["plasma"]["mu_e"], constants["plasma"]["mu_i"]
    D_e, D_i   = constants["plasma"]["D_e"],  constants["plasma"]["D_i"]

    phi = out_pde["phi"]
    ne  = out_pde["n_e"]
    ni  = out_pde["n_i"]

    # Gradients
    gphi = torch.autograd.grad(
        phi, pde_pts, grad_outputs=torch.ones_like(phi), create_graph=True
    )[0]
    gne = torch.autograd.grad(
        ne, pde_pts, grad_outputs=torch.ones_like(ne), create_graph=True
    )[0]
    gni = torch.autograd.grad(
        ni, pde_pts, grad_outputs=torch.ones_like(ni), create_graph=True
    )[0]

    phi_x, phi_y = gphi[:, 0:1], gphi[:, 1:2]
    ne_x,  ne_y  = gne[:, 0:1],  gne[:, 1:2]
    ni_x,  ni_y  = gni[:, 0:1],  gni[:, 1:2]

    # Currents
    Jex = -q * mu_e * ne * phi_x + q * D_e * ne_x
    Jey = -q * mu_e * ne * phi_y + q * D_e * ne_y
    Jix =  q * mu_i * ni * phi_x - q * D_i * ni_x
    Jiy =  q * mu_i * ni * phi_y - q * D_i * ni_y

    # Divergences
    div_Je_x = torch.autograd.grad(
        Jex, pde_pts, grad_outputs=torch.ones_like(Jex), create_graph=True
    )[0][:, 0:1]
    div_Je_y = torch.autograd.grad(
        Jey, pde_pts, grad_outputs=torch.ones_like(Jey), create_graph=True
    )[0][:, 1:2]
    div_Ji_x = torch.autograd.grad(
        Jix, pde_pts, grad_outputs=torch.ones_like(Jix), create_graph=True
    )[0][:, 0:1]
    div_Ji_y = torch.autograd.grad(
        Jiy, pde_pts, grad_outputs=torch.ones_like(Jiy), create_graph=True
    )[0][:, 1:2]

    res_e = div_Je_x + div_Je_y
    res_i = div_Ji_x + div_Ji_y

    # Poisson residual (2D Laplacian)
    phi_xx = torch.autograd.grad(
        phi_x, pde_pts, grad_outputs=torch.ones_like(phi_x), create_graph=True
    )[0][:, 0:1]
    phi_yy = torch.autograd.grad(
        phi_y, pde_pts, grad_outputs=torch.ones_like(phi_y), create_graph=True
    )[0][:, 1:2]
    res_poisson = -eps * (phi_xx + phi_yy) - q * (ni - ne)

    return torch.mean(res_e ** 2) + torch.mean(res_i ** 2) + 0.5 * torch.mean(res_poisson ** 2)
