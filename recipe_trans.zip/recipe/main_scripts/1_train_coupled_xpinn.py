# main_scripts/1_train_coupled_xpinn.py
from _bootstrap import *  # noqa

import os
import torch
from src.core.config_loader import load_config, fix_seeds, get_device
from src.core.trainer import XPINNTrainer
from src.core.data_sampler import DataSampler
from src.architectures.coupled_xpinn import CoupledXPINN, make_networks
from src.utils.plotting import plot_total_loss_curve, plot_combined_loss_curve, plot_individual_loss_curves, plot_final_fields

CFG_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "config", "process_recipe.json")
)

def main():
    cfg = load_config(CFG_PATH)
    print(f"[debug] Using config at: {CFG_PATH}")
    print(f"[debug] epochs={cfg['training']['epochs']}, lr={cfg['training']['lr']}")
    device = get_device(cfg)
    fix_seeds(cfg.get("seed", 42))

    os.makedirs(cfg["output"]["checkpoint_dir"], exist_ok=True)
    os.makedirs(cfg["output"]["fig_dir"], exist_ok=True)

    sampler = DataSampler(cfg, device)
    nets = make_networks(cfg).to(device)
    model = CoupledXPINN(cfg, nets).to(device)

    trainer = XPINNTrainer(cfg, model, sampler, device)
    hist = trainer.train()

    # --- Save the final model checkpoint ---
    checkpoint_path = os.path.join(cfg["output"]["checkpoint_dir"], "xpinn.pt")
    torch.save(model.state_dict(), checkpoint_path)
    print(f"Model saved to {checkpoint_path}")

    # --- Generate and save all plots ---
    print("\nGenerating final plots...")
    
    # 1. Plot ONLY the total loss
    # --- MODIFICATION: Update the filename to reflect the PDF format ---
    total_loss_save_path = os.path.join(cfg["output"]["fig_dir"], "total_loss_only.pdf")
    plot_total_loss_curve(hist["losses"], total_loss_save_path)
    
    # 2. Plot the combined overview of all losses
    plot_combined_loss_curve(hist["losses"], cfg["output"]["loss_plot_path"])
    
    # 3. Plot a separate figure for each physics domain's loss
    plot_individual_loss_curves(hist["losses"], cfg["output"]["fig_dir"])

    # 4. Plot the final predicted physical fields on the wafer
    #plot_final_fields(model, sampler, device, cfg["output"]["fig_dir"])
    
    print("\nTraining and plotting complete.")

if __name__ == "__main__":
    main()