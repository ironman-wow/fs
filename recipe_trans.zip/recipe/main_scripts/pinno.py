# main_scripts/3_train_pino_surrogate.py

import torch
import torch.nn as nn
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
import os
import joblib

# Import project modules
from src.core.config_loader import load_config

# --- 1. Custom Dataset for CSV data ---
class SemiconductorDataset(Dataset):
    """PyTorch Dataset for loading semiconductor process data from a CSV."""
    def __init__(self, features, labels):
        self.features = torch.tensor(features, dtype=torch.float32)
        self.labels = torch.tensor(labels, dtype=torch.float32)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return self.features[idx], self.labels[idx]


# --- 2. The Surrogate Model Architecture (MLP) ---
class PINO_Surrogate(nn.Module):
    """A simple but powerful MLP to act as the PINO surrogate."""
    def __init__(self, input_dim, output_dim, layers, neurons, activation_str):
        super().__init__()
        
        if activation_str == 'silu': activation_fn = nn.SiLU()
        elif activation_str == 'relu': activation_fn = nn.ReLU()
        else: activation_fn = nn.Tanh()

        net_layers = [nn.Linear(input_dim, neurons), activation_fn]
        for _ in range(layers - 1):
            net_layers.extend([nn.Linear(neurons, neurons), activation_fn])
        net_layers.append(nn.Linear(neurons, output_dim))
        
        self.net = nn.Sequential(*net_layers)

    def forward(self, x):
        return self.net(x)


def train_surrogate(config: dict, device: torch.device):
    """Main function to handle the training of the PINO surrogate model."""
    
    # --- 3. Data Loading and Preprocessing ---
    pino_cfg = config['pino_surrogate_config']
    data_path = config['output']['pino_data_path']
    
    if not os.path.exists(data_path):
        print(f"Error: PINO dataset not found at {data_path}")
        print("Please run '2_generate_pino_data.py' first.")
        return

    print(f"Loading dataset from {data_path}...")
    df = pd.read_csv(data_path)

    # Identify input (features) and output (labels) columns
    recipe_params = list(config['recipe_parameter_ranges'].keys())
    # All other columns are considered performance metrics (labels)
    kpi_labels = [col for col in df.columns if col not in recipe_params]
    
    print(f"Identified {len(recipe_params)} recipe parameters (features).")
    print(f"Identified {len(kpi_labels)} KPI metrics (labels).")

    X = df[recipe_params].values
    y = df[kpi_labels].values
    
    # Split data into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=pino_cfg['training_params']['validation_split'], random_state=42
    )

    # CRITICAL: Normalize the data. Fit ONLY on the training data.
    scaler_X = StandardScaler()
    scaler_y = StandardScaler()

    X_train_scaled = scaler_X.fit_transform(X_train)
    y_train_scaled = scaler_y.fit_transform(y_train)
    X_val_scaled = scaler_X.transform(X_val)
    y_val_scaled = scaler_y.transform(y_val)
    
    # Save the scalers for later use during optimization/inference
    scaler_path = os.path.dirname(config['output']['pino_model_save_path'])
    joblib.dump(scaler_X, os.path.join(scaler_path, 'scaler_X.pkl'))
    joblib.dump(scaler_y, os.path.join(scaler_path, 'scaler_y.pkl'))
    print("Data scalers saved for future inference.")

    # Create PyTorch datasets and dataloaders
    train_dataset = SemiconductorDataset(X_train_scaled, y_train_scaled)
    val_dataset = SemiconductorDataset(X_val_scaled, y_val_scaled)
    
    train_loader = DataLoader(train_dataset, batch_size=pino_cfg['training_params']['batch_size'], shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=pino_cfg['training_params']['batch_size'])

    # --- 4. Model, Loss, and Optimizer Setup ---
    model_cfg = pino_cfg['model_params']
    model = PINO_Surrogate(
        input_dim=len(recipe_params),
        output_dim=len(kpi_labels),
        layers=model_cfg['layers'],
        neurons=model_cfg['neurons'],
        activation_str=model_cfg['activation']
    ).to(device)
    
    print("\nPINO Surrogate Model Architecture:")
    print(model)
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Total trainable parameters: {total_params:,}")

    loss_fn = nn.MSELoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=pino_cfg['training_params']['learning_rate'])
    scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=pino_cfg['training_params']['scheduler_gamma'])

    # --- 5. The Training Loop ---
    best_val_loss = float('inf')
    epochs = pino_cfg['training_params']['epochs']
    
    print("\nStarting PINO surrogate training...")
    for epoch in range(epochs):
        model.train()
        train_loss = 0.0
        for features, labels in train_loader:
            features, labels = features.to(device), labels.to(device)
            
            optimizer.zero_grad()
            predictions = model(features)
            loss = loss_fn(predictions, labels)
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
        
        # Validation loop
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for features, labels in val_loader:
                features, labels = features.to(device), labels.to(device)
                predictions = model(features)
                loss = loss_fn(predictions, labels)
                val_loss += loss.item()
        
        train_loss /= len(train_loader)
        val_loss /= len(val_loader)
        
        if (epoch + 1) % 10 == 0:
            print(f"Epoch [{epoch+1}/{epochs}] | Train Loss: {train_loss:.6f} | Val Loss: {val_loss:.6f}")
            
        if (epoch + 1) % pino_cfg['training_params']['scheduler_step'] == 0:
            scheduler.step()
        
        # Save the best model
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), config['output']['pino_model_save_path'])

    print("\nTraining complete.")
    print(f"Best validation loss: {best_val_loss:.6f}")
    print(f"Trained PINO surrogate model saved to {config['output']['pino_model_save_path']}")
    print("\nNext step: Run '4_optimize_recipe.py' to find optimal recipes.")

if __name__ == "__main__":
    try:
        config = load_config('config/process_recipe.json')
        device = torch.device(config.get('device', 'cpu') if torch.cuda.is_available() else "cpu")
        train_surrogate(config, device)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}")