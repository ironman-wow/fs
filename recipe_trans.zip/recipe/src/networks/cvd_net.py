# src/networks/cvd_net.py
import torch
import torch.nn as nn
from .base_network import MLP


class CVDHead(nn.Module):
    """
    Predicts surface coverage θ and deposition rate R_dep.

    Inputs:
        shared: Tensor of shape (N, F) from the shared encoder
        X:      Original input tensor (N, 10), not used directly here but kept for API parity
        deps:   Optional dict of dependent fields (e.g., T, phi, n_e, n_i)
        constants: Optional dict of physical constants

    Outputs (dict):
        {
            "theta": Tensor (N, 1) in [0, 1],
            "R_dep": Tensor (N, 1) >= 0
        }
    """
    def __init__(self, in_dim: int, out_dim: int):
        super().__init__()
        assert out_dim == 2, "CVDHead must output 2 channels: [theta, R_dep]"
        self.mlp = MLP(in_dim, out_dim, width=128, depth=3)
        self._act_theta = nn.Sigmoid()
        self._act_rate = nn.Softplus()  # ensures non-negative deposition rate

    def forward(self, shared: torch.Tensor, X: torch.Tensor,
                deps: dict | None = None, constants: dict | None = None) -> dict:
        raw = self.mlp(shared)
        theta = self._act_theta(raw[:, 0:1])
        r_dep = self._act_rate(raw[:, 1:2])
        return {"theta": theta, "R_dep": r_dep}
