import os, json
import torch


class PINODataWriter:
def __init__(self, out_dir='pino_data'):
self.out_dir = out_dir
os.makedirs(out_dir, exist_ok=True)
self.samples = []
def add_sample(self, meta: dict, fields: dict):
# store small subset for PINO: temperature field & derived thickness proxy
# fields on grid are expected as flat tensors; keep as is for now
self.samples.append({"meta": meta, "fields": {k: v.detach().cpu().tolist() for k,v in fields.items() if k in ("T","theta","R_dep")}})
def flush(self):
with open(os.path.join(self.out_dir, 'dataset.json'), 'w') as f:
json.dump(self.samples, f)