# src/utils/plotting.py
import os
import torch
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# Set a consistent, publication-quality style for all plots
mpl.rcParams['figure.figsize'] = (8, 6)
mpl.rcParams['font.weight'] = 'bold'
mpl.rcParams['axes.labelweight'] = 'bold'
mpl.rcParams['axes.titleweight'] = 'bold'
# Ensure fonts are embedded in the PDF for portability
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42


def _save_as_pdf(fig, full_path):
    """Helper function to save a figure as a PDF, ensuring the directory exists."""
    base_name, _ = os.path.splitext(full_path)
    pdf_path = base_name + '.pdf'
    os.makedirs(os.path.dirname(pdf_path), exist_ok=True)
    fig.savefig(pdf_path, format='pdf', bbox_inches='tight')
    plt.close(fig)
    print(f"Saved figure to {pdf_path}")


def plot_total_loss_curve(history, save_path):
    """
    Plots ONLY the total loss curve on a single figure using a LINEAR scale.
    """
    if not history:
        print("Warning: Loss history is empty. Skipping total loss plot generation.")
        return

    epochs = range(len(history))
    fig, ax = plt.subplots()
    
    total_loss = [h["total"] for h in history]
    ax.plot(epochs, total_loss, label="Total Loss", color='black', linewidth=2.5)

    # --- Apply Styling (Linear Scale) ---
    ax.set_title("Total Training Loss", fontsize=18)
    ax.set_xlabel("Epoch", fontsize=16)
    ax.set_ylabel("Training Loss", fontsize=16) # Removed "(log scale)"
    ax.tick_params(axis='both', which='major', labelsize=14)
    # ax.set_yscale('log') # This line is removed for a linear scale
    ax.grid(True, which="both", linestyle='--', linewidth=0.5)
    ax.legend(fontsize=14)
    fig.tight_layout()
    
    _save_as_pdf(fig, save_path)


def plot_combined_loss_curve(history, save_path):
    """
    Plots the total loss and all individual component losses together on a single figure (log scale).
    """
    if not history:
        print("Warning: Loss history is empty. Skipping combined plot generation.")
        return

    epochs = range(len(history))
    fig, ax = plt.subplots()
    
    total_loss = [h["total"] for h in history]
    ax.plot(epochs, total_loss, label="Total Loss", color='black', linewidth=2.5, zorder=10)

    component_keys = [k for k in history[0].keys() if k != "total"]
    for key in component_keys:
        component_loss = [h.get(key, 0) for h in history]
        ax.plot(epochs, component_loss, label=f"{key.capitalize()} Loss", alpha=0.8, linestyle='--')

    ax.set_title("Combined Training Losses", fontsize=18)
    ax.set_xlabel("Epoch", fontsize=16)
    ax.set_ylabel("Training Loss (log scale)", fontsize=16)
    ax.tick_params(axis='both', which='major', labelsize=14)
    ax.set_yscale('log')
    ax.grid(True, which="both", linestyle='--', linewidth=0.5)
    ax.legend(fontsize=12)
    fig.tight_layout()
    
    _save_as_pdf(fig, save_path)


def plot_individual_loss_curves(history, save_dir):
    """
    Creates a separate plot for each individual loss component (NO total loss comparison).
    """
    if not history:
        print("Warning: Loss history is empty. Skipping individual plot generation.")
        return

    epochs = range(len(history))
    component_keys = [k for k in history[0].keys() if k != "total"]

    for key in component_keys:
        fig, ax = plt.subplots()
        
        component_loss = [h.get(key, 0) for h in history]
        
        # --- MODIFICATION: Only plot the specific component loss ---
        ax.plot(epochs, component_loss, label=f"{key.capitalize()} Loss", color='blue', linewidth=2.5)

        ax.set_title(f"{key.capitalize()} Loss Curve", fontsize=18) # Updated title
        ax.set_xlabel("Epoch", fontsize=16)
        ax.set_ylabel("Training Loss (log scale)", fontsize=16)
        ax.tick_params(axis='both', which='major', labelsize=14)
        ax.set_yscale('log')
        ax.grid(True, which="both", linestyle='--', linewidth=0.5)
        ax.legend(fontsize=14)
        fig.tight_layout()
        
        save_path = os.path.join(save_dir, f"loss_curve_{key}.pdf")
        _save_as_pdf(fig, save_path)


def plot_final_fields(model, sampler, device, save_dir):
    """
    Generates and saves a 2x2 plot of the final predicted physical fields.
    """
    model.eval()
    batch = sampler.sample_batch()
    grid_points = batch['grid'].to(device)
    
    recipe_params = { "T_chuck (K)": grid_points[0, 3].item(), "P_chamber (Pa)": grid_points[0, 4].item(), "P_rf (W)": grid_points[0, 5].item() }
    recipe_title = ", ".join([f"{k.split(' ')[0]}={v:.1f}" for k, v in recipe_params.items()])
    
    with torch.no_grad():
        predictions = model.forward_fields(grid_points)

    H = W = 64
    x_range, y_range = sampler.cfg['domain']['x_range'], sampler.cfg['domain']['y_range']
    extent = (x_range[0], x_range[1], y_range[0], y_range[1])
    
    X, Y = grid_points[:, 0].reshape(H, W).cpu().numpy(), grid_points[:, 1].reshape(H, W).cpu().numpy()
    mask = X**2 + Y**2 > sampler.R**2

    fields_to_plot = { 'T': {'title': 'Temperature (K)', 'data': predictions.get('T')}, 'sigma': {'title': 'Stress (Pa)', 'data': predictions.get('sigma')}, 'theta': {'title': 'Surface Coverage (θ)', 'data': predictions.get('theta')}, 'R_dep': {'title': 'Deposition Rate (m/s)', 'data': predictions.get('R_dep')} }

    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    fig.suptitle(f'Predicted Fields for Recipe:\n{recipe_title}', fontsize=18, weight='bold')
    
    for ax, key in zip(axes.flat, fields_to_plot.keys()):
        field_info = fields_to_plot[key]
        if field_info['data'] is None:
            ax.text(0.5, 0.5, f'{key}\n(not active)', ha='center', va='center', fontsize=16)
            ax.set_xticks([]); ax.set_yticks([])
            continue

        data = field_info['data'].reshape(H, W).cpu().numpy()
        data[mask] = np.nan
        
        im = ax.imshow(data, extent=extent, origin='lower', cmap='viridis')
        cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.ax.tick_params(labelsize=12)
        
        ax.set_title(field_info['title'], fontsize=16)
        ax.set_xlabel("x (m)", fontsize=14)
        ax.set_ylabel("y (m)", fontsize=14)
        ax.tick_params(axis='both', which='major', labelsize=12)

    fig.tight_layout(rect=[0, 0, 1, 0.95])
    save_path = os.path.join(save_dir, "final_predicted_fields.pdf")
    _save_as_pdf(fig, save_path)