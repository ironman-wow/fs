# src/physics_losses/thermal_loss.py
import torch

# Conservative heat equation:
#   rho * cp * dT/dt = div(k grad T) + Q
# We treat k as constant (from config) for stability in this baseline.

def thermal_residuals(pde_pts, ic_pts, bc_pts, out_pde, out_ic, out_bc, constants):
    rho = constants["thermal"]["rho"]
    cp  = constants["thermal"]["cp"]
    k   = constants["thermal"]["k"]
    Qs  = constants["thermal"]["Q_scale"]

    # PDE residuals on interior points
    T = out_pde["T"]
    grads = torch.autograd.grad(
        T, pde_pts, grad_outputs=torch.ones_like(T), create_graph=True
    )[0]
    Tx, Ty, Tt = grads[:, 0:1], grads[:, 1:2], grads[:, 2:3]

    Txx = torch.autograd.grad(
        Tx, pde_pts, grad_outputs=torch.ones_like(Tx), create_graph=True
    )[0][:, 0:1]
    Tyy = torch.autograd.grad(
        Ty, pde_pts, grad_outputs=torch.ones_like(Ty), create_graph=True
    )[0][:, 1:2]

    # Simple RF-power-to-source model: Q = Qs * P_rf
    P_rf = pde_pts[:, 5:6]
    Q = Qs * P_rf

    res_pde = rho * cp * Tt - k * (Txx + Tyy) - Q

    # IC: at t = t_min, T equals chuck temperature
    Tic = out_ic["T"]
    T_chuck_ic = ic_pts[:, 3:4]
    res_ic = Tic - T_chuck_ic

    # BC: insulated edge (r = R): n · ∇T ≈ 0
    x, y = bc_pts[:, 0:1], bc_pts[:, 1:2]
    r = torch.sqrt(x * x + y * y) + 1e-9
    Tbc = out_bc["T"]
    g_bc = torch.autograd.grad(
        Tbc, bc_pts, grad_outputs=torch.ones_like(Tbc), create_graph=True
    )[0]
    grad_n = (x * g_bc[:, 0:1] + y * g_bc[:, 1:2]) / r
    res_bc = grad_n

    return (
        torch.mean(res_pde ** 2)
        + 1.0 * torch.mean(res_ic ** 2)
        + 0.1 * torch.mean(res_bc ** 2)
    )
