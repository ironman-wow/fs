# src/core/trainer.py
from typing import Dict
import math
import torch
from torch import nn
from tqdm import trange


class XPINNTrainer:
    """
    Trainer with:
      - CUDA autocast + GradScaler for mixed precision
      - Per-epoch printing of thermal/cvd/plasma/stress and total losses (RAW)
      - EMA loss balancing (optional via cfg.training.balance) so each term contributes comparably
      - Non-finite guard: skip step, decay LR, keep training alive
      - Gradient clipping
      - History for plotting
    """
    def __init__(self, cfg: dict, model: nn.Module, sampler, device: torch.device):
        self.cfg = cfg
        self.model = model
        self.sampler = sampler
        self.device = device

        tr = cfg["training"]
        self.lr = float(tr["lr"])
        self.epochs = int(tr["epochs"])
        self.grad_clip = float(tr.get("grad_clip", 0.0)) or 0.0
        self.loss_weights = dict(tr.get("lambda", {}))
        self.device_type = "cuda" if device.type == "cuda" else "cpu"

        # Optimizer (Adam works well for PINNs)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)

        # AMP on CUDA only
        self.use_amp = bool(tr.get("mixed_precision", False) and self.device_type == "cuda")
        self.scaler = torch.amp.GradScaler(self.device_type) if self.use_amp else None

        # EMA balancing config
        bal = tr.get("balance", {"mode": "ema"})
        self.balance_mode = bal.get("mode", "ema")
        self.ema_beta = float(bal.get("beta", 0.98))
        self.ema_eps = float(bal.get("eps", 1e-9))
        clip = bal.get("clip", [1e-6, 1e6])
        self.ema_clip_min = float(clip[0]) if isinstance(clip, (list, tuple)) else 1e-6
        self.ema_clip_max = float(clip[1]) if isinstance(clip, (list, tuple)) else 1e6
        self._ema_scales: Dict[str, float] = {}

        self.history = {"losses": []}

    def _decay_lr_on_instability(self, factor: float = 0.5, min_lr: float = 1e-6):
        for g in self.optimizer.param_groups:
            g["lr"] = max(min_lr, g["lr"] * factor)

    @torch.no_grad()
    def _print_epoch(self, epoch_idx: int, losses: Dict[str, torch.Tensor], total: torch.Tensor):
        comp = {k: float(v.detach().item()) for k, v in losses.items()}
        msg = (f"epoch {epoch_idx+1}/{self.epochs} | total={total.item():.2e} "
               f"thermal={comp.get('thermal', float('nan')):.2e} "
               f"cvd={comp.get('cvd', float('nan')):.2e} "
               f"plasma={comp.get('plasma', float('nan')):.2e} "
               f"stress={comp.get('stress', float('nan')):.2e}")
        print(msg, flush=True)

    def _balanced_total(self, losses: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Build a total loss with optional EMA balancing so that each component
        is normalized by a running scale (approximate magnitude), then weighted by lambda.
        """
        total = torch.tensor(0.0, device=self.device)
        if self.balance_mode != "ema":
            # plain weighted sum
            for k, v in losses.items():
                w = float(self.loss_weights.get(k, 1.0))
                total = total + w * v
            return total

        # EMA-balanced
        for k, v in losses.items():
            raw = float(abs(v.detach().item()))
            if not math.isfinite(raw) or raw <= 0.0:
                raw = 1.0
            prev = self._ema_scales.get(k, raw)
            cur = self.ema_beta * prev + (1.0 - self.ema_beta) * raw
            cur = min(max(cur, self.ema_clip_min), self.ema_clip_max)
            self._ema_scales[k] = cur

            scale = torch.tensor(cur + self.ema_eps, device=self.device, dtype=v.dtype)
            w = float(self.loss_weights.get(k, 1.0))
            total = total + w * (v / scale)

        return total

    def train(self) -> Dict[str, list]:
        self.model.train()
        loop = trange(self.epochs)

        last_good_total = math.inf

        for ep in loop:
            batch = self.sampler.sample_batch()

            # Forward + loss under autocast
            if self.use_amp:
                with torch.amp.autocast(self.device_type, dtype=torch.float16):
                    losses = self.model.physics_losses(batch)
                    total = self._balanced_total(losses)
            else:
                losses = self.model.physics_losses(batch)
                total = self._balanced_total(losses)

            # Guard against NaN/Inf
            if not torch.isfinite(total):
                self.optimizer.zero_grad(set_to_none=True)
                self._decay_lr_on_instability()
                loop.set_description("L=nonfinite (skipped)")
                continue

            self.optimizer.zero_grad(set_to_none=True)

            if self.use_amp:
                self.scaler.scale(total).backward()
                if self.grad_clip > 0:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                total.backward()
                if self.grad_clip > 0:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
                self.optimizer.step()

            # Log + UI (RAW values; total is balanced if enabled)
            log = {k: float(v.detach().item()) for k, v in losses.items()}
            log["total"] = float(total.detach().item())
            self.history["losses"].append(log)
            loop.set_description(f"L={log['total']:.4e}")
            loop.set_postfix({
                "thermal": f"{log.get('thermal', float('nan')):.2e}",
                "cvd": f"{log.get('cvd', float('nan')):.2e}",
                "plasma": f"{log.get('plasma', float('nan')):.2e}",
                "stress": f"{log.get('stress', float('nan')):.2e}",
                "lr": f"{self.optimizer.param_groups[0]['lr']:.1e}"
            })
            self._print_epoch(ep, losses, total)

            # Simple LR anneal on plateau/increase (gentle)
            if log["total"] > last_good_total * 1.02:
                self._decay_lr_on_instability(factor=0.9)
            else:
                last_good_total = min(last_good_total, log["total"])

        return self.history
