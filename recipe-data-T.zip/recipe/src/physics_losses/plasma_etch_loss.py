# src/physics_losses/plasma_etch_loss.py
from typing import Dict, Tuple
import torch


def _get(out: Dict[str, torch.Tensor], names) -> torch.Tensor:
    for n in names:
        if n in out:
            return out[n]
    raise KeyError(f"None of {names} found in model outputs: {list(out.keys())}")


def _grad(y: torch.Tensor, X: torch.Tensor, dim: int) -> torch.Tensor:
    """dy/dx_dim for scalar y wrt X[:, dim]."""
    ones = torch.ones_like(y)
    g = torch.autograd.grad(y, X, grad_outputs=ones, create_graph=True, retain_graph=True)[0]
    return g[:, dim:dim+1]


def _laplacian_2d(y: torch.Tensor, X: torch.Tensor, x_idx: int = 0, y_idx: int = 1) -> torch.Tensor:
    """∂²y/∂x² + ∂²y/∂y² using autograd."""
    gx = _grad(y, X, x_idx)
    gy = _grad(y, X, y_idx)
    gxx = torch.autograd.grad(gx, X, grad_outputs=torch.ones_like(gx), create_graph=True, retain_graph=True)[0][:, x_idx:x_idx+1]
    gyy = torch.autograd.grad(gy, X, grad_outputs=torch.ones_like(gy), create_graph=True, retain_graph=True)[0][:, y_idx:y_idx+1]
    return gxx + gyy


def _norm_mean_sq(res: torch.Tensor, eps: float = 1e-12) -> torch.Tensor:
    """(res / std_detached)^2 mean, to keep scales ~O(1)."""
    std = res.detach().std().clamp_min(eps)
    return ((res / std) ** 2).mean()


def _extract_fields(out: Dict[str, torch.Tensor]) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    phi = _get(out, ["phi", "plasma_phi", "V", "potential"])         # (N,1)
    ne  = _get(out, ["n_e", "ne", "plasma_ne", "electron_density"])  # (N,1)
    ni  = _get(out, ["n_i", "ni", "plasma_ni", "ion_density"])       # (N,1)
    return phi, ne, ni


def plasma_residuals(pde_X: torch.Tensor,
                     bc_X: torch.Tensor,
                     out_pde: Dict[str, torch.Tensor],
                     out_bc: Dict[str, torch.Tensor],
                     constants: Dict) -> torch.Tensor:
    """
    Minimal, usable plasma loss:
      - Poisson: ∇²φ + (q/ε)(n_i - n_e) = 0
      - Electron continuity: ∇·( -μ_e n_e ∇φ - D_e ∇n_e ) - S = 0
      - Ion continuity:      ∇·( +μ_i n_i ∇φ - D_i ∇n_i ) - S = 0
      - Boundary: φ(R,θ)=0 (grounded), n_e(R,θ)=n_w, n_i(R,θ)=1.1 n_w   (simple sheath)
    All residuals are normalized by their batch std to avoid vanishing scales.
    """
    dev = pde_X.device
    dtype = pde_X.dtype

    eps0   = torch.as_tensor(constants["plasma"]["epsilon"], device=dev, dtype=dtype)
    q      = torch.as_tensor(constants["plasma"]["q"],        device=dev, dtype=dtype)
    mu_e   = torch.as_tensor(constants["plasma"]["mu_e"],     device=dev, dtype=dtype)
    mu_i   = torch.as_tensor(constants["plasma"]["mu_i"],     device=dev, dtype=dtype)
    D_e    = torch.as_tensor(constants["plasma"]["D_e"],      device=dev, dtype=dtype)
    D_i    = torch.as_tensor(constants["plasma"]["D_i"],      device=dev, dtype=dtype)

    # Reference scales for simple source/BC magnitudes
    # Use chamber pressure and RF power from input features:
    # Feature order: [x, y, t, T_chuck, P_chamber, P_rf, SiH4, NH3, AUX1, AUX2]
    P_chamber_pde = pde_X[:, 4:5]
    P_rf_pde      = pde_X[:, 5:6]
    P_chamber_bc  = bc_X[:, 4:5]
    P_rf_bc       = bc_X[:, 5:6]

    # Simple ionization source ~ c_s * (P_rf normalized) * n_e
    # Coeff chosen to give an O(1) residual after normalization; tweak if needed.
    c_s   = torch.as_tensor(1e-2, device=dev, dtype=dtype)
    S_pde = c_s * (P_rf_pde / (P_rf_pde.detach().mean().clamp_min(1.0))) * 1.0  # dimensionless factor

    # Pull model fields
    phi_pde, ne_pde, ni_pde = _extract_fields(out_pde)
    phi_bc,  ne_bc,  ni_bc  = _extract_fields(out_bc)

    # Poisson residual on PDE points
    lap_phi = _laplacian_2d(phi_pde, pde_X, 0, 1)
    pois = lap_phi + (q / eps0) * (ni_pde - ne_pde)

    # Electron continuity: div(J_e) - S = 0, J_e = -μ_e n_e ∇φ - D_e ∇n_e
    dphidx = _grad(phi_pde, pde_X, 0); dphidy = _grad(phi_pde, pde_X, 1)
    dnex   = _grad(ne_pde,  pde_X, 0); dney   = _grad(ne_pde,  pde_X, 1)
    Jex = -mu_e * ne_pde * dphidx - D_e * dnex
    Jey = -mu_e * ne_pde * dphidy - D_e * dney
    dJexdx = _grad(Jex, pde_X, 0); dJeydy = _grad(Jey, pde_X, 1)
    cont_e = dJexdx + dJeydy - S_pde

    # Ion continuity: div(J_i) - S = 0, J_i = +μ_i n_i ∇φ - D_i ∇n_i
    dnix   = _grad(ni_pde,  pde_X, 0); dniy   = _grad(ni_pde,  pde_X, 1)
    Jix = +mu_i * ni_pde * dphidx - D_i * dnix
    Jiy = +mu_i * ni_pde * dphidy - D_i * dniy
    dJixdx = _grad(Jix, pde_X, 0); dJiydy = _grad(Jiy, pde_X, 1)
    cont_i = dJixdx + dJiydy - S_pde

    # --- Boundary conditions (simple but non-trivial) ---
    # Grounded wall: φ = 0
    bc_phi = phi_bc  # target 0
    # Sheath-like densities: set small but nonzero wall densities proportional to pressure
    # n_w = c_n * P_chamber (normalized), and n_i slightly larger than n_e to induce space charge
    c_n = torch.as_tensor(1e13, device=dev, dtype=dtype)  # reference density scale
    Pnorm_bc = P_chamber_bc / (P_chamber_bc.detach().mean().clamp_min(1.0))
    n_wall = c_n * Pnorm_bc
    bc_ne = ne_bc - n_wall
    bc_ni = ni_bc - 1.1 * n_wall

    # Normalize each residual by its detached std to keep numeric scales healthy
    L_pois = _norm_mean_sq(pois)
    L_ce   = _norm_mean_sq(cont_e)
    L_ci   = _norm_mean_sq(cont_i)
    L_bphi = _norm_mean_sq(bc_phi)    # target 0
    L_bne  = _norm_mean_sq(bc_ne)
    L_bni  = _norm_mean_sq(bc_ni)

    # Final plasma loss: sum of normalized residuals
    L_plasma = L_pois + L_ce + L_ci + 0.5 * (L_bphi + L_bne + L_bni)
    return L_plasma
