# src/core/data_sampler.py
from typing import Dict
import torch
from torch.quasirandom import SobolEngine


class DataSampler:
    """
    Sobol/uniform sampling over (x, y, t) within a wafer disk; attaches recipe params.

    Input feature order everywhere:
      [x, y, t, T_chuck, P_chamber, P_rf, SiH4, NH3, AUX1, AUX2] -> (N, 10)
    """
    def __init__(self, cfg: dict, device: torch.device):
        self.cfg = cfg
        self.device = device

        dom = cfg["domain"]
        self.xmin, self.xmax = dom["x_range"]
        self.ymin, self.ymax = dom["y_range"]
        self.tmin, self.tmax = dom["t_range"]
        self.R = dom["wafer_radius"]

        self.n_points = cfg["training"]["batch_points"]
        self.viz_grid = int(cfg["training"].get("viz_grid", 32))
        self.sobol = SobolEngine(dimension=3, scramble=True)

    def _sample_xy_in_disc(self, n: int) -> torch.Tensor:
        samples = []
        count = 0
        while len(samples) < n and count < 10 * n:
            xy = torch.rand((n, 2), device=self.device)
            xy[:, 0] = self.xmin + (self.xmax - self.xmin) * xy[:, 0]
            xy[:, 1] = self.ymin + (self.ymax - self.ymin) * xy[:, 1]
            mask = (xy[:, 0] ** 2 + xy[:, 1] ** 2) <= (self.R ** 2)
            if mask.any():
                samples.append(xy[mask])
            count += 1
        if not samples:
            return torch.zeros((n, 2), device=self.device)
        return torch.cat(samples, dim=0)[:n]

    def _sample_t(self, n: int) -> torch.Tensor:
        u = torch.rand((n, 1), device=self.device)
        return self.tmin + (self.tmax - self.tmin) * u

    def _sample_recipe(self, n: int) -> Dict[str, torch.Tensor]:
        rr = self.cfg["recipe_parameter_ranges"]
        def uni(a, b): return a + (b - a) * torch.rand((n, 1), device=self.device)
        return {
            "T_chuck": uni(*rr["T_chuck"]),
            "P_chamber": uni(*rr["P_chamber"]),
            "P_rf": uni(*rr["P_rf"]),
            "SiH4": uni(*rr["flows_sccm"]["SiH4"]),
            "NH3": uni(*rr["flows_sccm"]["NH3"])
        }

    def _pack(self, xy: torch.Tensor, t: torch.Tensor, recipe: Dict[str, torch.Tensor]) -> torch.Tensor:
        n = xy.shape[0]
        aux = torch.zeros((n, 2), device=self.device)
        xyt = torch.cat([xy, t], dim=1)
        recipe_vec = torch.cat(
            [recipe["T_chuck"], recipe["P_chamber"], recipe["P_rf"], recipe["SiH4"], recipe["NH3"]],
            dim=1,
        )
        return torch.cat([xyt, recipe_vec, aux], dim=1)

    def sample_batch(self) -> Dict[str, torch.Tensor]:
        n_pde = int(self.n_points["pde"])
        n_bc = int(self.n_points["bc"])
        n_ic = int(self.n_points["ic"])

        xy = self._sample_xy_in_disc(n_pde)
        t = self._sample_t(n_pde)
        rec = self._sample_recipe(n_pde)
        pde = self._pack(xy, t, rec).requires_grad_(True)

        xy_ic = self._sample_xy_in_disc(n_ic)
        t_ic = torch.full((n_ic, 1), self.tmin, device=self.device)
        rec_ic = self._sample_recipe(n_ic)
        ic = self._pack(xy_ic, t_ic, rec_ic).requires_grad_(True)

        # Edge points: r = R
        ang = 2.0 * torch.pi * torch.rand((n_bc, 1), device=self.device)
        xy_bc = torch.cat([self.R * torch.cos(ang), self.R * torch.sin(ang)], dim=1)
        t_bc = self._sample_t(n_bc)
        rec_bc = self._sample_recipe(n_bc)
        bc = self._pack(xy_bc, t_bc, rec_bc).requires_grad_(True)

        # Dense grid for visualization (mid-time)
        H = W = self.viz_grid
        xs = torch.linspace(self.xmin, self.xmax, W, device=self.device)
        ys = torch.linspace(self.ymin, self.ymax, H, device=self.device)
        X, Y = torch.meshgrid(xs, ys, indexing="xy")
        Tmid = torch.full_like(X.reshape(-1, 1), (self.tmin + self.tmax) / 2)
        rec_g = self._sample_recipe(X.numel())
        grid = self._pack(torch.stack([X.reshape(-1), Y.reshape(-1)], dim=1), Tmid, rec_g)

        meta = {k: float(v.mean().item()) for k, v in rec.items()}

        return {"pde": pde, "ic": ic, "bc": bc, "grid": grid, "meta": meta}
