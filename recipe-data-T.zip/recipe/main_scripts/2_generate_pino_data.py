from _bootstrap import * # noqa
import os, json, torch
from tqdm import trange
from src.core.config_loader import load_config, get_device
from src.architectures.coupled_xpinn import CoupledXPINN, make_networks
from src.core.data_sampler import DataSampler
from src.utils.pino_data_formatter import PINODataWriter


CFG_PATH = os.path.join(os.path.dirname(__file__), '..', 'config', 'process_recipe.json')
CFG_PATH = os.path.abspath(CFG_PATH)


if __name__ == "__main__":
cfg = load_config(CFG_PATH)
device = get_device(cfg)


nets = make_networks(cfg).to(device)
model = CoupledXPINN(cfg, nets).to(device)
ckpt = os.path.join(cfg['output']['checkpoint_dir'], 'xpinn.pt')
model.load_state_dict(torch.load(ckpt, map_location=device))
model.eval()


sampler = DataSampler(cfg, device)
writer = PINODataWriter(out_dir='pino_data')


N = 64 # number of recipes/snapshots to export
for _ in trange(N):
batch = sampler.sample_batch()
with torch.no_grad():
out = model.forward_fields(batch['grid'])
writer.add_sample(batch['meta'], out)
writer.flush()